library("optparse")
library("plyr")
library("gtools")
library("tidyverse")
library("ggplot2")
library("reshape2")

#' @export get.expr.status
get.expr.status <- function(Expr1.value=NULL,Expr2.value=NULL,Log2FC.value=NULL,pVal.value=NULL,threshold_log2fc=1,threshold_pval=0.01,threshold_expr=50){
  
  status.vec <- 0
  if(is.na(Log2FC.value) || is.na(pVal.value) || Log2FC.value=="NA" || pVal.value=="NA") {
    status.vec <- 0
  } else {
    status.vec <- ifelse(abs(Log2FC.value)<threshold_log2fc || pVal.value>threshold_pval || pmax(as.vector(Expr2.value),as.vector(Expr1.value))<threshold_expr, 0, ifelse(as.vector(Log2FC.value)>0,1,2))
  }           
  
  return(status.vec) 
}


#' @export get.expr.status2, when no expr value provided
get.expr.status2 <- function(Log2FC.value=NULL,pVal.value=NULL,threshold_log2fc=1,threshold_pval=0.01){
  
  status.vec <- 0
  if(is.na(Log2FC.value) || is.na(pVal.value) || Log2FC.value=="NA" || pVal.value=="NA") {
    status.vec <- 0
  } else {
    status.vec <- ifelse(abs(Log2FC.value)<threshold_log2fc || pVal.value>threshold_pval, 0, ifelse(as.vector(Log2FC.value)>0,1,2))
  }           
  
  return(status.vec) 
}


#' @export get.user.parameters 
get.user.parameters <- function(paramFile=NULL){
  params.m <- as.data.frame(read.delim(paramFile,
                                       header=T,row.names=1 ,as.is=T,quote="",sep="\t"),stringsAsFactors=F)
  return(params.m)
}


#' @export get.DEFE.no.expr
get.DEFE.no.expr <- function(prefix="P",params.m=NULL,data.m=NULL,threshold_log2fc=1,threshold_pval=0.01) {
  
  data.m.pattern <- NULL
  
  numComp=dim(params.m)[1]
  
  for(i in 1:numComp){
    
    # append to each of the four vectors  
    params.for.compare <- params.m[i,]
    # the main execution loop. 
    
    log2FC.col.vec <- data.m[,params.for.compare[1,1]]
    p.col.vec <- data.m[,params.for.compare[1,2]]
    
    tmp.vec <- NULL
    
    for(j in 1:length(log2FC.col.vec)) {
      # get DEFE pattern for gene i:
      # get four values for each comparison
      log2FC.value <- log2FC.col.vec[j]
      pVal.value <- p.col.vec[j]
      
      
      # append the DEFE pattern of this gene to the DEFE.vec
      if(is.null(tmp.vec)){
        
        tmp.vec <- get.expr.status2(log2FC.value, pVal.value, threshold_log2fc, threshold_pval)
      }else{
        tmp.vec<- c(tmp.vec,get.expr.status2(log2FC.value, pVal.value, threshold_log2fc, threshold_pval))
      }
    }
    
    if(is.null(data.m.pattern)){
      data.m.pattern <- as.data.frame(tmp.vec)
    }else{
      data.m.pattern <- cbind(data.m.pattern,as.data.frame(tmp.vec))
    }
    
  }
  
  data.m.pattern <- cbind(prefix,data.m.pattern)
  rownames(data.m.pattern) <- rownames(data.m)
  colnames(data.m.pattern) <- c("prefix",rownames(params.m))
  
  return(data.m.pattern)
}


#' @export get.DEFE 
get.DEFE <- function(prefix="P",params.m=NULL,data.m=NULL,threshold_log2fc=1,threshold_pval=0.01,threshold_expr=50) {
  
  data.m.pattern <- NULL
  numComp=dim(params.m)[1]
  
  for(i in 1:numComp){
    
    # append to each of the four vectors  
    params.for.compare <- params.m[i,]
    # the main execution loop. 
    
    expr1.col.vec <- data.m[,params.for.compare[1,1]]
    expr2.col.vec <- data.m[,params.for.compare[1,2]]
    log2FC.col.vec <- data.m[,params.for.compare[1,3]]
    p.col.vec <- data.m[,params.for.compare[1,4]]
    
    tmp.vec <- NULL
    
    for(j in 1:length(expr1.col.vec)) {
      # get DEFE pattern for gene i:
      # get four values for each comparison
      expr1.value <- expr1.col.vec[j]
      expr2.value <- expr2.col.vec[j]
      log2FC.value <- log2FC.col.vec[j]
      pVal.value <- p.col.vec[j]
      
      
      # append the DEFE pattern of this gene to the DEFE.vec
      if(is.null(tmp.vec)){
        
        tmp.vec <- get.expr.status(expr1.value, expr2.value, log2FC.value, pVal.value, threshold_log2fc, threshold_pval, threshold_expr)
      }else{
        tmp.vec<- c(tmp.vec,get.expr.status(expr1.value, expr2.value, log2FC.value, pVal.value, threshold_log2fc, threshold_pval,threshold_expr))
      }
    }
    
    if(is.null(data.m.pattern)){
      data.m.pattern <- as.data.frame(tmp.vec)
    }else{
      data.m.pattern <- cbind(data.m.pattern,as.data.frame(tmp.vec))
    }
    
  }
  
  data.m.pattern <- cbind(prefix,data.m.pattern)
  rownames(data.m.pattern) <- rownames(data.m)
  colnames(data.m.pattern) <- c("prefix",rownames(params.m))
  
  return(data.m.pattern)
}


#' @export get.pattern.vec
get.pattern.vec <- function(data.m.pattern=NULL){
  
  pattern.vec <- apply(data.m.pattern,1,function(x)paste(x,collapse=""))
  
  return(pattern.vec)
}


#' @export get.pattern.freq 
get.pattern.freq <- function(pattern.vec=NULL){ 
  gene.freq.m  <- pattern.vec %>% as_tibble() %>% count(value)
  gene.freq.m <- as.data.frame(gene.freq.m)
  
  colnames(gene.freq.m) <- c("pattern","freq")
  rownames(gene.freq.m) <- gene.freq.m$pattern
  
  return(gene.freq.m)
}

#' @export freq.pattern.plot
freq.pattern.plot <- 
  function(patternfreq=NULL,rmsubset=50,color="blue") 
  {
    
    p1 <- ggplot(patternfreq, aes(x=reorder(pattern, -freq),y=as.numeric(freq))) +
      geom_bar(stat = "identity",color=color,fill=color) +
      scale_y_continuous(expand = c(0, 0), limits = c(0, max(patternfreq[,2])*1.05))+
      xlab("DEFE Patterns") + ylab("Number of Genes") + theme_bw() +
      theme(axis.title = element_text(face = "bold",size=16), axis.text = element_text(face = "bold",size=14),axis.text.x = element_text(angle = 90, vjust=0.5, hjust=1,size=14),axis.text.y = element_text(face = "bold",size=14), axis.title.y = element_text(margin = unit(c(0, 5, 0, 0), "mm"),face="bold",size=16),panel.grid.major = element_blank(),panel.grid.minor = element_blank(),axis.title.x = element_text(margin = unit(c(5, 0, 0, 0), "mm"),face="bold",size=16)) 
    
    return(p1)
  }

#' @export freq.DEGs.plot
freq.DEGs.plot <- function(data.m.pattern)
{
  
  m.dpm <- melt(data.m.pattern[,-1])
  updn <- cbind(data.frame(m.dpm[,2]),NA)
  updn[grep("1",updn[,1]),2] <- "UP"
  updn[grep("2",updn[,1]),2] <- "DN"
  updn[grep("0",updn[,1]),2] <- "UNC"
  
  m.dpm$value <- as.factor(m.dpm$value)
  m.dpm$variable <- as.factor(m.dpm$variable)
  m.dpm <- cbind(m.dpm,updn[,2])
  colnames(m.dpm)[3] <- "exp"
  
  
  p2 <- ggplot(m.dpm[-grep("UNC",m.dpm[,"exp"]),],aes(fill = factor(exp, levels=c("UP", "DN")))) + 
    geom_bar(aes(x=variable),position = "stack", stat="count") + 
    scale_fill_manual(values=list("UP"="red","DN"="blue")) +
    xlab("Differential Expression Analysis") + ylab("Number of Genes") + theme_bw() + scale_y_continuous(expand = c(0, 0)) +
    theme(legend.title = element_blank(),axis.text.x = element_text(angle = 90,  vjust=0.5, hjust=1,face = "bold",size=14), axis.text.y = element_text(face = "bold",size=14), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),axis.title = element_text(face = "bold",size=16), axis.text = element_text(face = "bold",size=14), axis.title.y = element_text(margin = unit(c(0, 5, 0, 0), "mm"),face = "bold",size=16), axis.title.x = element_text(margin = unit(c(5, 0, 0, 0), "mm"),face = "bold",size=16))
  
  
  return(p2)
}

#' @export freq.remove.zero.col
freq.remove.zero.col <- function(data.m.pattern=NULL) {
  numComp <- dim(data.m.pattern)[2]-1
  prefix <- data.m.pattern[1,1]  
  
  patternfreq <- get.pattern.freq(get.pattern.vec(data.m.pattern))
  patternfreq <- patternfreq[mixedsort(as.character(patternfreq$pattern)),]
  
  zero.col <- paste(prefix,paste(as.vector(rep("0",numComp)),collapse=""),sep="")
  
  if(length(grep(zero.col,patternfreq$pattern))>0){
    patternfreq <- patternfreq[-grep(zero.col,patternfreq$pattern),]
  }
  patternfreq <- patternfreq[order(-patternfreq$freq),]
  
  return(patternfreq)
  
}

#' @export freq.save.png
freq.save.png <- function(data.m.pattern=NULL,out.filename="patternfeqdiagram.png",rmsubset=50,color="blue"){ 
  
  patternfreq <- freq.remove.zero.col(data.m.pattern)
  rmsubset <- min(rmsubset, dim(patternfreq)[1])
  patternfreq <- patternfreq[1:rmsubset,]
  
  p1 <- freq.pattern.plot(patternfreq,rmsubset,color)
  p2 <- freq.DEGs.plot(data.m.pattern)
  
  png(filename = out.filename,width = 1200, height = 600, units = "px")
  print(p1 + annotation_custom(ggplotGrob(p2), xmin = (dim(patternfreq)[1]/2)*1.3, xmax = rmsubset+0.4, ymin = (max(patternfreq[,2])-max(patternfreq[,2]*0.6)), ymax = (max(patternfreq[,2])+max(patternfreq[,2]*0.02))))
  dev.off()
}


#' @export freq.save.bmp
freq.save.bmp <- function(data.m.pattern=NULL,out.filename="patternfeqdiagram.bmp",rmsubset=50,color="blue"){ 
  
  patternfreq <- freq.remove.zero.col(data.m.pattern)
  rmsubset <- min(rmsubset, dim(patternfreq)[1])
  patternfreq <- patternfreq[1:rmsubset,]
  
  p1 <- freq.pattern.plot(patternfreq,rmsubset,color)
  p2 <- freq.DEGs.plot(data.m.pattern)
  
  png(filename = out.filename,width = 1200, height = 600, units = "px")
  print(p1 + annotation_custom(ggplotGrob(p2), xmin = (dim(patternfreq)[1]/2)*1.3, xmax = rmsubset+0.4, ymin = (max(patternfreq[,2])-max(patternfreq[,2]*0.6)), ymax = (max(patternfreq[,2])+max(patternfreq[,2]*0.02))))
  dev.off()
}

#' @export freq.save.jpeg
freq.save.jpeg <- function(data.m.pattern=NULL,out.filename="patternfeqdiagram.jpeg",rmsubset=50,color="blue"){ 
  
  patternfreq <- freq.remove.zero.col(data.m.pattern)
  rmsubset <- min(rmsubset, dim(patternfreq)[1])
  patternfreq <- patternfreq[1:rmsubset,]
  
  p1 <- freq.pattern.plot(patternfreq,rmsubset,color)
  p2 <- freq.DEGs.plot(data.m.pattern)
  
  png(filename = out.filename,width = 1200, height = 600, units = "px")
  print(p1 + annotation_custom(ggplotGrob(p2), xmin = (dim(patternfreq)[1]/2)*1.3, xmax = rmsubset+0.4, ymin = (max(patternfreq[,2])-max(patternfreq[,2]*0.6)), ymax = (max(patternfreq[,2])+max(patternfreq[,2]*0.02))))
  dev.off()
}

#' @export freq.save.tiff
freq.save.tiff <- function(data.m.pattern=NULL,out.filename="patternfeqdiagram.tiff",rmsubset=50,color="blue"){ 
  
  patternfreq <- freq.remove.zero.col(data.m.pattern)
  rmsubset <- min(rmsubset, dim(patternfreq)[1])
  patternfreq <- patternfreq[1:rmsubset,]
  
  p1 <- freq.pattern.plot(patternfreq,rmsubset,color)
  p2 <- freq.DEGs.plot(data.m.pattern)
  
  png(filename = out.filename,width = 1200, height = 600, units = "px")
  print(p1 + annotation_custom(ggplotGrob(p2), xmin = (dim(patternfreq)[1]/2)*1.3, xmax = rmsubset+0.4, ymin = (max(patternfreq[,2])-max(patternfreq[,2]*0.6)), ymax = (max(patternfreq[,2])+max(patternfreq[,2]*0.02))))
  dev.off()
}

